from Visitor import Visitor
from StaticError import *
from Utils import Utils
from AST import *

# 2010236


class NoType(Type):
    pass


class GetEnv(Visitor):
    def __init__(self, ast):
        self.ast = ast

    # get all enviroment of program
    def getName(self, decl):
        return decl[0]

    def visitProgram(self, ast, param):
        # Read an integer number from keyboard and return it
        param[0] += [["readInteger", IntegerType(), []]]
        # Write an integer number to the screen
        param[0] += [["printInteger",
                      VoidType(), [["anArg", IntegerType(), False, False]]]]

        # Read an float number from keyboard and return it
        param[0] += [["readFloat", FloatType(), []]]
        # Write an float number to the screen
        param[0] += [["printFloat", VoidType(), [["anArg", FloatType(), False, False]]]]

        # Read an boolean value from keyboard and return it
        param[0] += [["readBoolean", BooleanType(), []]]
        # Write an boolean value to the screen
        param[0] += [["printBoolean",
                      VoidType(), [["anArg", BooleanType(), False, False]]]]

        # Read an string from keyboard and return it
        param[0] += [["readString", StringType(), []]]
        # Write an string to the screen
        param[0] += [["printString", VoidType(), [["anArg", StringType(), False, False]]]]

        # Call the parent function with the list of expression as paramaters
        param[0] += [["super", VoidType(), []]]
        # Prevent default parent function to be called
        param[0] += [["preventDefault", VoidType(), []]]

        for decl in ast.decls:
            if type(decl) is FuncDecl:
                param = self.visit(decl, param)

        return param

    def visitParamDecl(self, ast, param):
        # param is local environment of parameter
        # if Utils().lookup(ast.name, param, self.getName) is not None:
        #     raise Redeclared(Parameter(), ast.name)

        param += [[ast.name, ast.typ, ast.out, ast.inherit]]
        return param

    def visitFuncDecl(self, ast, param):
        # if Utils().lookup(ast.name, param[0], self.getName) is not None:
        #     raise Redeclared(Function(), ast.name)

        params = []
        for fparam in ast.params:
            params = self.visit(fparam, params)

        param[0] += [[ast.name, ast.return_type, params]]
        return param


class StaticChecker(Visitor):
    def __init__(self, ast):
        self.ast = ast

    def check(self):
        return self.visitProgram(self.ast, [[]])

    def getName(self, decl):
        return decl[0]

    def infer(self, name, param, typ):
        for scope in param:
            if scope == []:
                continue
            for iname in scope:
                if name == iname[0]:
                    # update type for indentifier
                    iname[1] = self.visit(typ, param)
                    return

    def check_print(self, o):
        self.f.write(str(o) + '\n')

    def visitIntegerType(self, ast, param):
        return IntegerType()

    def visitFloatType(self, ast, param):
        return FloatType()

    def visitBooleanType(self, ast, param):
        return BooleanType()

    def visitStringType(self, ast, param):
        return StringType()

    def visitArrayType(self, ast, param):
        return ArrayType(ast.dimensions, ast.typ)

    def visitAutoType(self, ast, param):
        return AutoType()

    def visitVoidType(self, ast, param):
        return VoidType()

    def visitBinExpr(self, ast, param):
        # param[0] is environment that contains binary expressions
        left = self.visit(ast.left, param)
        ## 23/4/2023##
        if type(left) is bool:
            raise IllegalArrayLiteral(ast.left)
        right = self.visit(ast.right, param)
        ## 23/4/2023##
        if type(right) is bool:
            raise IllegalArrayLiteral(ast.right)

        if ast.op == '%' and (type(left) is not IntegerType or type(right) is not IntegerType):
            raise TypeMismatchInExpression(ast)

        if ast.op in ['+', '-', '*', '/']:
            # left or right is auto => what type of left and right
            l = type(left) is IntegerType or type(left) is FloatType
            r = type(right) is IntegerType or type(right) is FloatType
            if type(left) is AutoType:
                # left is parameter
                if not r:
                    raise TypeMismatchInExpression(ast)
                self.infer(ast.left.name, param[1:], right)
                return right

            if type(right) is AutoType:
                # left is parameter
                if not l:
                    raise TypeMismatchInExpression(ast)
                self.infer(ast.right.name, param[1:], left)
                return left

            if not l or not r:  # left and right is not Integer of Float
                raise TypeMismatchInExpression(ast)

            if type(left) is FloatType or type(right) is FloatType:
                return FloatType()

            return IntegerType()

        if ast.op in ['>', '<', '>=', '<=']:
            # left or right is auto => what type of left and right
            l = type(left) is IntegerType or type(left) is FloatType
            r = type(right) is IntegerType or type(right) is FloatType

            if type(left) is AutoType:
                if not r:
                    raise TypeMismatchInExpression(ast)

                self.infer(ast.left.name, param, right)
                return BooleanType()

            if type(right) is AutoType:
                if not l:
                    raise TypeMismatchInExpression(ast)

                self.infer(ast.right.name, param, left)
                return BooleanType()

            if not l or not r:
                raise TypeMismatchInExpression(ast)
            return BooleanType()

        if ast.op in ['&&', "||"]:
            if type(left) is AutoType and type(right) is BooleanType:
                self.infer(ast.left.name, param, right)
                return BooleanType()

            if type(right) is AutoType and type(left) is BooleanType:
                self.infer(ast.right.name, param, left)
                return BooleanType()

            if type(left) is not BooleanType or type(right) is not BooleanType:
                raise TypeMismatchInExpression(ast)
            return BooleanType()

        if ast.op == "::":
            if type(left) is AutoType and type(right) is StringType:
                self.infer(ast.left.name, param, right)
                return StringType()

            if type(right) is AutoType and type(left) is StringType:
                self.infer(ast.right.name, param, left)
                return StringType()

            if type(left) is not StringType or type(right) is not StringType:
                raise TypeMismatchInExpression(ast)
            return StringType()

        if ast.op in ['==', '!=']:
            l = type(left) is IntegerType or type(left) is BooleanType
            r = type(right) is IntegerType or type(right) is BooleanType

            if type(left) is AutoType and r:
                self.infer(ast.left.name, param, right)
                return BooleanType()

            if type(right) is AutoType and l:
                self.infer(ast.right.name, param, left)
                return BooleanType()

            if not l or not r:
                raise TypeMismatchInExpression(ast)
            # what happen when l != r??
            return BooleanType()

    def visitUnExpr(self, ast, param):
        expr = self.visit(ast.val, param)
        if type(expr) is bool:
            IllegalArrayLiteral(ast.val)
        # self.check_print(expr)

        if ast.op == '-':
            # what happen when expr is autotype??
            if type(expr) is AutoType:
                self.infer(ast.val.name, param, IntegerType())
                return IntegerType()
            if type(expr) is not FloatType and type(expr) is not IntegerType:
                raise TypeMismatchInExpression(ast)
            return expr
        if ast.op == '!':
            if type(expr) is AutoType:
                self.infer(ast.val.name, param, BooleanType())
                return BooleanType()
            if type(expr) is not BooleanType:
                raise TypeMismatchInExpression(ast)
            return BooleanType()

    def visitId(self, ast, param):
        # self.check_print(param)
        # self.check_print(ast.name)

        for scope in param:
            if scope == []:
                continue
            for _id in scope:
                if _id[0] == ast.name:
                    return _id[1]

        raise Undeclared(Identifier(), ast.name)

    def visitArrayCell(self, ast, param):
        _id = self.visit(Id(ast.name), param)  # find array name
        # get dim and atomic type
        dim = _id.dimensions
        typ = _id.typ

        for _cell in ast.cell:
            cellType = self.visit(_cell, param)
            if type(cellType) is not IntegerType:
                raise TypeMismatchInExpression(ast)

        if len(dim) == len(ast.cell):
            return typ  # get smallest element
        return ArrayType(dim[len(ast.cell):], typ)

    def visitIntegerLit(self, ast, param):
        return IntegerType()

    def visitFloatLit(self, ast, param):
        return FloatType()

    def visitStringLit(self, ast, param):
        return StringType()

    def visitBooleanLit(self, ast, param):
        return BooleanType()

    def visitArrayLit(self, ast, param):
        if type(ast.explist[0]) is not ArrayLit:
            typ = self.visit(ast.explist[0], param)
            for e in ast.explist[1:]:
                etype = self.visit(e, param)

                if type(typ) != type(etype):
                    if type(typ) is AutoType:
                        typ = etype
                        self.infer(ast.explist[0].name, param, etype)
                    elif type(etype) is AutoType:
                        self.infer(e.name, param, etype)
                    else:
                        # raise IllegalArrayLiteral(e)
                        return False
            return ArrayType([len(ast.explist)], typ)
        else:
            typ = self.visit(ast.explist[0], param)
            if type(typ) is bool:
                return False

            for e in ast.explist[1:]:
                etype = self.visit(e, param)
                if type(etype) is bool:
                    return False
                # if typ != etype:
                #     raise IllegalArrayLiteral(e)
            # self.check_print(typ.dimessions)
            return ArrayType([len(ast.explist)] + typ.dimensions, typ.typ)

    def implementAssign(self, lhs, rhs, ast, param, super):
        # param[0] is local, param[1] is global

        right = self.visit(rhs, param)
        ## 23/4/2023##
        if type(right) is bool:
            raise IllegalArrayLiteral(rhs)
        left = self.visit(lhs, param)
        ## 23/4/2023##
        if type(left) is bool:
            raise IllegalArrayLiteral(lhs)

        # self.check_print(str(lhs) + " " + str(left))
        # self.check_print(str(rhs) + " " + str(right))

        if type(left) is ArrayType or type(left) is VoidType:
            if super:
                raise TypeMismatchInExpression(ast)  # for super
            raise TypeMismatchInStatement(ast)

        if type(right) != type(left):
            if type(right) is not AutoType and type(left) is not AutoType:
                if super:
                    raise TypeMismatchInExpression(ast)  # for super
                raise TypeMismatchInStatement(ast)
        # right or left is autotype
        if type(right) is AutoType:
            self.infer(rhs.name, param, left)  # find id and assign type for it
            return
        if type(left) is AutoType:
            # find id and assign type for it
            self.infer(lhs.name, param, right)
            return

        if type(left) != type(right):
            if type(left) is not FloatType or type(right) is not IntegerType:
                if super:
                    raise TypeMismatchInExpression(ast)  # for super
                raise TypeMismatchInStatement(ast)

    def visitFuncCall(self, ast, param):
        # param[0] is local
        # param[-1] is global

        # create new environment for function call
        func = Utils().lookup(ast.name, param[-1], self.getName)
        if func is None:
            raise Undeclared(Function(), ast.name)

        env = []
        for parameter in func[2]:
            env += [[parameter[0], parameter[1]]]

        # func[0] is name
        # func[1] is return type
        # func[2] is list of parameter p = [[p1][p2][p3]]
        # p1 is parameter: p1[0] is name, p1[1] is type, p1[2] is out, p1[3] is inherit

        if type(func[1]) is VoidType:
            raise TypeMismatchInExpression(ast)

        if len(func[2]) != len(ast.args):
            raise TypeMismatchInExpression(ast)

        # update type for parameter
        for i in range(len(func[2])):
            parameter = Id(func[2][i][0])
            argument = ast.args[i]

            if type(argument) is bool:
                raise IllegalArrayLiteral(ast.argument)

            self.implementAssign(parameter, argument, ast, [env] + param, 0)
            self.infer(func[2][i][0], [func[2]], self.visit(
                argument, param))  # update type for function
            # self.implementAssign(parameter, argument, ast, param) #update type for environment variable

        for i in range(len(param[-1])):
            if param[-1][i][0] == func[0]:
                param[-1][i][2] = func[2]
                break

        return func[1]  # return return type of function

    def handleInherit(self, ast, param):
        # ast is a function declare
        # check parameter of function with parameter of parent function
        # get prototype of present function
        funcN = Utils().lookup(ast.name, param[-1], self.getName)

        # parameter
        pParams = self.fParent[2]

        # check prototype of parent
        for i in range(len(pParams)):
            for j in range(i + 1, len(pParams)):
                if pParams[j][0] == pParams[i][0]:
                    raise Redeclared(Parameter(), pParams[i][0])

        # add inherit param of parent to child
        if len(pParams) != 0:
            # parent function have no parameter
            # check invalid parameters
            # funcNow is name of function is being called
            # pParam = fParent[2][0:] is list of parameters of parent function
            # pParam[0] is name, pParam[1] is type, pParam[2] is out, pParam[3] is inherit
            # get parameter in env
            for pParam in pParams:
                if pParam[3]:  # parameter is inherit
                    param[0] += [[pParam[0], pParam[1]]]

        for fparam in funcN[2]:  # find invalid parameters
            parameter = Utils().lookup(fparam[0], pParams, self.getName)
            if parameter is not None and parameter[3]:
                raise Invalid(Parameter(), fparam[0])
        return

    def handleSuper(self, ast, param):
        pParams = self.fParent[2]  # get parameters of parent
        env = []
        for parameter in pParams:
            env += [[parameter[0], parameter[1]]]

        # get present function
        funcN = Utils().lookup(self.funcNow, param[-1], self.getName)

        for fparam in funcN[2]:
            # add param of function to local
            param[0] += [[fparam[0], fparam[1]]]

        # infer type for parent of present function
        parentArgs = ast.args  # get arguments

        func = Utils().lookup(self.fParent[0], param[-1], self.getName)
        # func[0] is name of function
        # func[1] is return type of function
        # func[2] is parameter list

        if len(parentArgs) < len(func[2]):
            # super have different arguments for parent function
            raise TypeMismatchInExpression(None)
        elif len(parentArgs) > len(func[2]):
            index = len(parentArgs) - len(func[2]) + 1
            raise TypeMismatchInExpression(parentArgs[index])

        for i in range(len(func[2])):
            parameter = Id(func[2][i][0])
            argument = ast.args[i]

            if type(argument) is bool:
                raise IllegalArrayLiteral(ast.argument)

            # pass by name, funcall
            if func[2][i][2] and type(argument) is not FuncCall:
                raise TypeMismatchInExpression(argument)

            self.implementAssign(parameter, argument,
                                 argument, [env] + param, 1)
            self.infer(func[2][i][0], [func[2]], self.visit(argument, param))
            # self.implementAssign(parameter, argument, ast, param)

        for i in range(len(param[-1])):
            if param[-1][i][0] == func[0]:
                param[-1][i][2] = func[2]
                break

        return

    def handlePrevent(self, ast, param):
        return

    def visitCallStmt(self, ast, param):
        # param[0] is local
        # param[-2] is global
        # param[-1] is function name

        func = Utils().lookup(ast.name, param[-1], self.getName)
        if func is None:
            raise Undeclared(Function(), ast.name)

        env = []
        for parameter in func[2]:
            env += [[parameter[0], parameter[1]]]

        # if type(func[1]) is AutoType or type(func[1]) is VoidType:
        #     func[1] = VoidType()
        # else:
        #     raise TypeMismatchInStatement(ast)

        if ast.name != 'super' and ast.name != 'preventDefault':
            if len(func[2]) != len(ast.args):  # have different arguments ??
                raise TypeMismatchInStatement(ast)
        elif ast.name == 'super':
            self.handleSuper(ast, param)
            return
        else:
            self.handlePrevent(ast, param)
            return

        # update type for parameter
        for i in range(len(func[2])):
            parameter = Id(func[2][i][0])
            argument = ast.args[i]

            if type(argument) is bool:
                raise IllegalArrayLiteral(ast.argument)

            # pass by name, funcall
            if func[2][i][2] and type(argument) is not FuncCall:
                raise TypeMismatchInExpression(argument)

            self.implementAssign(parameter, argument, ast, [env] + param, 0)
            self.infer(func[2][i][0], [func[2]], self.visit(argument, param))
            # self.implementAssign(parameter, argument, ast, param)

        for i in range(len(param[-1])):
            if param[-1][i][0] == func[0]:
                param[-1][i][2] = func[2]
                break

        return

    def visitAssignStmt(self, ast, param):
        # param[0] is local
        # param[-2] is global
        # param[-1] is function name
        self.implementAssign(ast.lhs, ast.rhs, ast, param, 0)

    def visitBlockStmt(self, ast, param):
        # param[0] is local
        # param[-1] is function list

        if self.mainBlock > 0:
            param = [[]] + param
        self.mainBlock += 1

        if self.fParent is not None:  # function have parent
            pParams = self.fParent[2]  # get parameters of parent
            if len(pParams) != 0:
                if len(ast.body) == 0:
                    raise InvalidStatementInFunction(self.funcNow)

                if type(ast.body[0]) is not CallStmt:
                    raise InvalidStatementInFunction(self.funcNow)
                if ast.body[0].name != "super" and ast.body[0].name != "preventDefault":
                    raise InvalidStatementInFunction(self.funcNow)

        for in_body in ast.body:
            self.instruction += 1
            if type(in_body) is VarDecl:
                param = self.visit(in_body, param)
            else:
                self.visit(in_body, param)
                if type(in_body) is CallStmt and (in_body.name == "super" or in_body.name == "preventDefault"):
                    parent = Utils().lookup(
                        self.fParent[0], param[-1], self.getName)
                    for variable in parent[2]:
                        self.infer(variable[0], param, variable[1])
                    self.fParent = None

        self.mainBlock -= 1
        param = param[1:]

    # check condition in if/while/do-while statement whether is boolean
    def check_cond(self, ast, cond, param):
        expr = self.visit(cond, param)
        if type(expr) is not BooleanType:
            raise TypeMismatchInStatement(ast)

    def visitIfStmt(self, ast, param):
        # param[0] is local environment contain if statement
        # param[-1] is global of whole program
        self.check_cond(ast, ast.cond, param)

        env = [[]]

        #
        if type(ast.tstmt) is not BlockStmt:
            self.mainBlock += 1

        self.visit(ast.tstmt, env + param)

        if type(ast.tstmt) is not BlockStmt:
            self.mainBlock -= 1

        if ast.fstmt is not None:
            if type(ast.tstmt) is not BlockStmt:
                self.mainBlock += 1

            self.visit(ast.fstmt, env + param)

            if type(ast.tstmt) is not BlockStmt:
                self.mainBlock -= 1

        # if self.ifReturn is None and self.elseReturn is None:
        #     return

        # if self.ifReturn is None:
        #     if self.returnNow is None:
        #         self.returnNow = self.elseReturn
        #     else:
        #         if self.getReturn(self.returnNow) != self.getReturn(self.elseReturn):
        #             raise TypeMismatchInStatement(self.elseReturn)
        # elif self.elseReturn is not None:
        #     if self.returnNow is None:
        #         self.returnNow = self.ifReturn
        #     else:
        #         if self.getReturn(self.returnNow) != self.getReturn(self.ifReturn):
        #             raise TypeMismatchInStatement(self.ifReturn)
        # else:
        #     if self.getReturn(self.ifReturn) != self.getReturn(self.elseReturn):
        #         raise TypeMismatchInStatement(self.elseReturn)

    def visitForStmt(self, ast, param):
        # param[0] is local environment contain if statement
        # param[-1] is global of whole program list

        self.visit(ast.init, param)
        self.check_cond(ast, ast.cond, param)

        upd = self.visit(ast.upd, param)
        if type(upd) is not IntegerType:
            raise TypeMismatchInStatement(ast)

        self.pLoop += 1
        if type(ast.stmt) is not BlockStmt:
            self.mainBlock += 1
        env = []
        self.visit(ast.stmt, [env] + param)

        if type(ast.stmt) is not BlockStmt:
            self.mainBlock -= 1
        self.pLoop -= 1

    def visitWhileStmt(self, ast, param):
        # param[0] is local environment of return statement
        # param[-2] is global of whole program
        # param[-1] is function name list

        self.check_cond(ast, ast.cond, param)
        self.pLoop += 1
        if type(ast.stmt) is not BlockStmt:
            self.mainBlock += 1
        env = []
        self.visit(ast.stmt, [env] + param)

        if type(ast.stmt) is not BlockStmt:
            self.mainBlock -= 1
        self.pLoop -= 1

    def visitDoWhileStmt(self, ast, param):
        # param[0] is local environment of return statement
        # param[-2] is global of whole program
        # param[-1] is function name list

        self.check_cond(ast, ast.cond, param)
        self.pLoop += 1
        env = []
        self.visit(ast.stmt, [env] + param)
        self.pLoop -= 1

    def visitBreakStmt(self, ast, param):
        # param[0] is local environment of return statement
        # param[-2] is global of whole program
        # param[-1] is function name
        if self.pLoop > 0:
            return
        raise MustInLoop(ast)

    def visitContinueStmt(self, ast, param):
        # param[0] is local environment of return statement
        # param[-2] is global of whole program
        # param[-1] is function name
        if self.pLoop > 0:
            return
        raise MustInLoop(ast)

    def getReturn(self, expr, param):
        if expr is None:
            return VoidType()
        return self.visit(expr, param)

    def chooseReturn(self, ast, typ):
        if self.returnNow is None:
            self.returnNow = [typ, self.mainBlock, self.instruction]
        elif type(self.returnNow[0]) != type(typ):
            raise TypeMismatchInStatement(ast)

    def visitReturnStmt(self, ast, param):
        # param[0] is local environment of return statement
        # param[-1] is global of whole program
        # get name of function

        # return in mainblock  => just check the first return
        # return is not in main block => set all return
        funcName = self.funcNow
        funcType = Utils().lookup(funcName, param[-1], self.getName)[1]
        if ast.expr is not None:
            rType = self.visit(ast.expr, param)

            if type(rType) is bool:
                raise IllegalArrayLiteral(ast.expr)

            if type(funcType) is VoidType:
                raise TypeMismatchInStatement(ast)

            if type(funcType) != type(rType):
                if type(funcType) is AutoType:
                    # self.infer(funcName, [param[-1]], rType)
                    if self.returnNow is None:
                        self.returnNow = [
                            rType, self.mainBlock, self.instruction]
                    else:
                        if self.mainBlock == self.returnNow[1] and type(self.returnNow[0]) != type(rType):
                            raise TypeMismatchInStatement(ast)
                elif type(rType) is AutoType:
                    return  # ??
                else:
                    raise TypeMismatchInStatement(ast)
        else:
            if type(funcType) is not AutoType and type(funcType) is not VoidType:
                raise TypeMismatchInStatement(ast)
            # self.infer(funcName, [param[-1]], VoidType())
            if self.returnNow is None:
                self.returnNow = [VoidType(), self.mainBlock, self.instruction]
            else:
                if self.mainBlock == self.returnNow[1] and type(self.returnNow[0]) != type(rType):
                    raise TypeMismatchInStatement(ast)
        ##############################################################################

    def check_ArrayType(typ, dim):
        for ele in dim:
            if type(ele) != type(typ):
                return 0
        return 1

    def visitVarDecl(self, ast, param):
        # param[0] is local of variable declaration
        if Utils().lookup(ast.name, param[0], self.getName) is not None:
            raise Redeclared(Variable(), ast.name)

        # typ = init
        typ = ast.typ

        if ast.init is None:
            if type(typ) is AutoType:
                raise Invalid(Variable(), ast.name)
        else:
            e = self.visit(ast.init, param)  # return an type object
            ## 23/4/2023##
            if type(e) is bool:
                raise IllegalArrayLiteral(ast.init)

            # self.check_print(e)
            if type(typ) is AutoType:
                ast.typ = e
            elif type(typ) is ArrayType:
                if type(e) is ArrayType:
                    if typ.dimensions != e.dimensions or type(typ.typ) != type(e.typ):
                        raise TypeMismatchInVarDecl(ast)
                else:
                    raise TypeMismatchInVarDecl(ast)
            elif type(typ) != type(e):
                if type(typ) is FloatType and type(e) is IntegerType:
                    ast.typ = FloatType()
                else:
                    raise TypeMismatchInVarDecl(ast)
        param[0] += [[ast.name, ast.typ]]
        return param

    def visitParamDecl(self, ast, param):
        if Utils().lookup(ast.name, param, self.getName) is not None:
            raise Redeclared(Parameter(), ast.name)

        param += [[ast.name, ast.typ]]
        return param

    def visitFuncDecl(self, ast, param):
        # param is local of function declaration
        # param is
        # self.check_print(ast.name)

        self.returnNow = None
        self.instruction = 0
        if Utils().lookup(ast.name, param[0], self.getName) is not None:
            raise Redeclared(Function(), ast.name)

        env = []
        self.funcNow = ast.name

        # add param of fucntinn to local
        for func in param[-1]:
            if func[0] == ast.name:
                for fparam in func[2]:
                    if Utils().lookup(fparam[0], env, self.getName) is not None:
                        raise Redeclared(Parameter(), fparam[0])

                    env += [[fparam[0], fparam[1]]]

        # implement inherit
        if ast.inherit is not None:
            parent = Utils().lookup(ast.inherit, param[-1], self.getName)
            if parent is None:
                raise Undeclared(Function(), ast.inherit)
            self.fParent = parent
            self.handleInherit(ast, [env] + param)

        # self.check_print(env)

        param[0] += [[ast.name, ast.return_type]]

        self.mainBlock = 0
        self.visit(ast.body,  [env] + param)

        # update return_type######################################################################
        # if self.returnNow is not None:
        #     if type(ast.return_type) is AutoType:
        #         self.infer(ast.name, [param[-1]], self.returnNow)
        #     else:
        #         if type(self.returnNow) != type(ast.return_type):
        #             raise TypeMismatchInStatement()
        # else:
        #     if type(ast.return_type) is AutoType:
        #         self.infer(ast.name, [param[-1]], VoidType())
        if self.returnNow is not None:
            self.infer(ast.name, [param[-1]], self.returnNow[0])

        # self.check_print(self.returnNow)
        self.instruction = 0
        return param

    def visitProgram(self, ast, param):
        self.funcNow = ""
        self.fParent = None
        self.pLoop = 0
        self.mainBlock = 0  # main block of present function
        self.returnNow = None  # [type, block number]
        self.instruction = 0
        self.f = open("print.txt", "w")

        enviroment = GetEnv(ast)
        param = enviroment.visit(ast, param)  # get all declares

        param = [[]] + param
        for decl in ast.decls:
            param = self.visit(decl, param)

        # find main function
        found = False
        for func in param[-1]:
            if func[0] == 'main' and type(func[1]) is VoidType and func[2] == []:
                found = True
                break
        if not found:
            raise NoEntryPoint()

        self.f.close()
        # return ""
