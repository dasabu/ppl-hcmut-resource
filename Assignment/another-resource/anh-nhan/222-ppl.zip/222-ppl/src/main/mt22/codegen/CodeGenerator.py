from Emitter import Emitter
from functools import reduce

from Frame import Frame
from abc import ABC
from Visitor import *
from AST import *
# from main.mt22.utils.AST import *
# from main.mt22.utils.Visitor import *


class MType:
    def __init__(self, partype, rettype):
        self.partype = partype
        self.rettype = rettype


class ClassType(Type):
    def __init__(self, cname):
        self.cname = cname

    def __str__(self):
        return "Class({0})".format(str(self.cname))

    def accept(self, v, param):
        return None


class Symbol:
    def __init__(self, name, mtype, value=None, isBuiltin=False):
        self.name = name
        self.mtype = mtype
        self.value = value
        self.isBuiltin = isBuiltin

    def __str__(self):
        return "Symbol(" + self.name + "," + str(self.mtype) + ")"


class CodeGenerator:
    def __init__(self):
        self.libName = "io"

    def init(self):
        return [Symbol("readInteger", MType(list(), IntegerType()), CName(self.libName), True),
                Symbol("printInteger", MType(
                    [IntegerType()], VoidType()), CName(self.libName), True),
                Symbol("readFloat", MType([], FloatType()),
                       CName(self.libName), True),
                Symbol("writeFloat", MType(
                    [FloatType()], VoidType()), CName(self.libName), True),
                Symbol("readBoolean", MType([], BooleanType()),
                       CName(self.libName), True),
                Symbol("printBoolean", MType(
                    [BooleanType()], VoidType()), CName(self.libName), True),
                Symbol("readString", MType([], StringType()),
                       CName(self.libName), True),
                Symbol("printString", MType(
                    [StringType()], VoidType()), CName(self.libName), True)
                ]

    def gen(self, ast, path):
        # ast: AST
        # dir_: String

        gl = self.init()
        gc = CodeGenVisitor(ast, gl, path)
        gc.visit(ast, None)


class SubBody():
    def __init__(self, frame, sym):
        self.frame = frame
        self.sym = sym

    def addSymbol(self, sym):
        self.sym = [sym] + self.sym


class Access():
    def __init__(self, frame, sym, isLeft, isFirst=False):
        self.frame = frame
        self.sym = sym
        self.isLeft = isLeft
        self.isFirst = isFirst

    def addSymbol(self, sym):
        self.sym = [sym] + self.sym


class Val(ABC):
    pass


class Index(Val):
    def __init__(self, value):
        self.value = value


class CName(Val):
    def __init__(self, value):
        self.value = value


class CodeGenVisitor(Visitor):
    def __init__(self, astTree, env, path):
        self.astTree = astTree
        self.env = env
        self.path = path
        self.initStmt = []
        self.className = "MT22Class"
        self.emit = Emitter(self.path + "/" + self.className + ".j")

    def visitProgram(self, ast, c):
        self.emit.printout(self.emit.emitPROLOG(
            self.className, "java.lang.Object"))
        e = SubBody(None, self.env)
        for x in ast.decls:
            if type(x) is FuncDecl:
                e.addSymbol(Symbol(x.name, MType(
                    list(map(lambda t: t.typ, x.params)), x.return_type), CName(self.className)))
        for x in ast.decls:
            e = self.visit(x, e)
        # generate default constructor
        self.genMETHOD(FuncDecl("<init>", None, list(), None,
                       BlockStmt(list())), c, Frame("<init>", VoidType))
        self.genMETHOD(FuncDecl("<clinit>", VoidType(), list(), None, BlockStmt(
            self.initStmt)), e.sym, Frame("<clinit>", VoidType))
        self.emit.emitEPILOG()
        return c

    def genMETHOD(self, consdecl, o, frame):
        isInit = consdecl.return_type is None
        isMain = consdecl.name == "main" and len(
            consdecl.params) == 0 and type(consdecl.return_type) is VoidType
        isClinit = consdecl.name == "<clinit>"
        returnType = VoidType() if isInit or isClinit else consdecl.return_type
        methodName = "<init>" if isInit else consdecl.name
        intype = [ArrayType([0], StringType())] if isMain else list(
            map(lambda x: x.typ, consdecl.params))
        mtype = MType(intype, returnType)

        self.emit.printout(self.emit.emitMETHOD(
            methodName, mtype, not isInit, frame))

        frame.enterScope(True)

        glenv = o

        # Generate code for parameter declarations
        if isInit:
            self.emit.printout(self.emit.emitVAR(frame.getNewIndex(), "this", ClassType(
                self.className), frame.getStartLabel(), frame.getEndLabel(), frame))
        elif isClinit:
            self.emit.printout(self.emit.emitVAR(frame.getNewIndex(), "this", ClassType(
                self.className), frame.getStartLabel(), frame.getEndLabel(), frame))
        elif isMain:
            self.emit.printout(self.emit.emitVAR(frame.getNewIndex(), "args", ArrayType(
                [0], StringType()), frame.getStartLabel(), frame.getEndLabel(), frame))
        else:
            local = reduce(lambda env, ele: SubBody(
                frame, [self.visit(ele, env)]+env.sym), consdecl.params, SubBody(frame, []))
            glenv = local.sym+glenv
        body = consdecl.body
        self.emit.printout(self.emit.emitLABEL(frame.getStartLabel(), frame))

        # Generate code for statements
        if isInit:
            self.emit.printout(self.emit.emitREADVAR(
                "this", ClassType(self.className), 0, frame))
            self.emit.printout(self.emit.emitINVOKESPECIAL(frame))
        subbody = SubBody(frame, glenv)
        list(map(lambda x: self.visit(x, subbody), body.body))
        self.emit.printout(self.emit.emitLABEL(frame.getEndLabel(), frame))
        if type(returnType) is VoidType:
            self.emit.printout(self.emit.emitRETURN(VoidType(), frame))
        else:
            self.emit.printout(self.emit.emitRETURN(returnType, frame))
        self.emit.printout(self.emit.emitENDMETHOD(frame))
        frame.exitScope()

    def visitFuncDecl(self, ast, o):
        subctxt = o
        frame = Frame(ast.name, ast.return_type)
        self.genMETHOD(ast, subctxt.sym, frame)
        return subctxt

    def visitVarDecl(self, ast, o):
        if o.frame is None:
            self.emit.printout(self.emit.emitATTRIBUTE(
                ast.name, ast.typ, False, ''))

            o.addSymbol(Symbol(ast.name, ast.typ, CName(self.className)))

            if ast.init is not None:
                self.initStmt = self.initStmt + \
                    [AssignStmt(Id(ast.name), ast.init)]
            elif type(ast.typ) is ArrayType:
                if type(ast.typ.typ) is IntegerType:
                    val = IntegerLit(0)
                elif type(ast.typ.typ) is FloatType:
                    val = FloatLit(0.0)
                elif type(ast.typ.typ) is StringType:
                    val = StringLit("")
                elif type(ast.typ.typ) is BooleanType:
                    val = BooleanLit(False)
                init = ArrayLit([val for i in range(ast.typ.dimensions[-1])])
                for i in ast.typ.dimensions[::-1][1:]:
                    init = ArrayLit([init for j in range(i)])
                self.initStmt = self.initStmt + \
                    [AssignStmt(Id(ast.name), init)]

            return o
        else:
            # in_ = o.frame.getCurrIndex()
            # o.frame.setCurrIndex(in_ + 1)
            in_ = o.frame.getNewIndex()
            self.emit.printout(self.emit.emitVAR(
                in_, ast.name, ast.typ, o.frame.getStartLabel(), o.frame.getEndLabel(), o.frame))
            o.addSymbol(Symbol(ast.name, ast.typ, Index(in_)))
            if ast.init is not None:
                self.visit(AssignStmt(Id(ast.name), ast.init), o)
            return o

    def visitParamDecl(self, ast, o):
        in_ = o.frame.getNewIndex()
        self.emit.printout(self.emit.emitVAR(
            in_, ast.name, ast.typ, o.frame.getStartLabel(), o.frame.getEndLabel(), o.frame))
        return Symbol(ast.name, ast.typ, Index(in_))

    def visitAssignStmt(self, ast, o):
        if type(ast.lhs) is not ArrayCell:
            rcode, rtyp = self.visit(ast.rhs, Access(o.frame, o.sym, False))
            lcode, ltyp = self.visit(ast.lhs, Access(o.frame, o.sym, True))
            if type(rtyp) is IntegerType and type(ltyp) is FloatType:
                rcode += self.emit.emitI2F(o.frame)
            self.emit.printout(rcode + lcode)
        else:
            lcode, ltyp = self.visit(ast.lhs, Access(o.frame, o.sym, True))
            rcode, rtyp = self.visit(ast.rhs, Access(o.frame, o.sym, False))
            if type(rtyp) is IntegerType and type(ltyp) is FloatType:
                rcode += self.emit.emitI2F(o.frame)
            self.emit.printout(
                lcode + rcode + self.emit.emitASTORE(ltyp, o.frame))

    def visitBlockStmt(self, ast, o):
        o.frame.enterScope(False)
        start = o.frame.getStartLabel()
        end = o.frame.getEndLabel()
        glenv = o.sym
        self.emit.printout(self.emit.emitLABEL(start, o.frame))
        subbody = SubBody(o.frame, glenv)
        list(map(lambda x: self.visit(x, subbody), ast.body))
        self.emit.printout(self.emit.emitLABEL(end, o.frame))
        o.frame.exitScope()

    def visitIfStmt(self, ast, o):
        code, typ = self.visit(ast.cond, Access(o.frame, o.sym, False))
        self.emit.printout(code)
        if ast.fstmt is None:
            label = o.frame.getNewLabel()
            self.emit.printout(self.emit.emitIFFALSE(label, o.frame))
            self.visit(ast.tstmt, o)
            self.emit.printout(self.emit.emitLABEL(label, o.frame))
        else:
            tlabel = o.frame.getNewLabel()
            elabel = o.frame.getNewLabel()
            self.emit.printout(self.emit.emitIFFALSE(elabel, o.frame))
            self.visit(ast.tstmt, o)
            self.emit.printout(self.emit.emitGOTO(tlabel, o.frame))
            self.emit.printout(self.emit.emitLABEL(elabel, o.frame))
            self.visit(ast.fstmt, o)
            self.emit.printout(self.emit.emitLABEL(tlabel, o.frame))

    def visitForStmt(self, ast, o):
        o.frame.enterLoop()
        con = o.frame.getContinueLabel()
        brk = o.frame.getBreakLabel()
        start = o.frame.getNewLabel()
        self.visit(ast.init, o)
        self.emit.printout(self.emit.emitLABEL(start, o.frame))
        code, _ = self.visit(ast.cond, Access(o.frame, o.sym, False))
        self.emit.printout(code)
        self.emit.printout(self.emit.emitIFFALSE(brk, o.frame))
        self.visit(ast.stmt, o)
        self.emit.printout(self.emit.emitLABEL(con, o.frame))
        self.visit(AssignStmt(ast.init.lhs, BinExpr(
            '+', ast.init.lhs, ast.upd)), o)
        self.emit.printout(self.emit.emitGOTO(start, o.frame))
        self.emit.printout(self.emit.emitLABEL(brk, o.frame))
        o.frame.exitLoop()

    def visitWhileStmt(self, ast, o):
        o.frame.enterLoop()
        con = o.frame.getContinueLabel()
        brk = o.frame.getBreakLabel()
        self.emit.printout(self.emit.emitLABEL(con, o.frame))
        code, _ = self.visit(ast.cond, Access(o.frame, o.sym, False))
        self.emit.printout(code)
        self.emit.printout(self.emit.emitIFFALSE(brk, o.frame))
        self.visit(ast.stmt, o)
        self.emit.printout(self.emit.emitGOTO(con, o.frame))
        self.emit.printout(self.emit.emitLABEL(brk, o.frame))
        o.frame.exitLoop()

    def visitDoWhileStmt(self, ast, o):
        o.frame.enterLoop()
        con = o.frame.getContinueLabel()
        brk = o.frame.getBreakLabel()
        start = o.frame.getNewLabel()
        self.emit.printout(self.emit.emitLABEL(start, o.frame))
        self.visit(ast.stmt, o)
        code, _ = self.visit(ast.cond, Access(o.frame, o.sym, False))
        self.emit.printout(self.emit.emitLABEL(con, o.frame))
        self.emit.printout(code)
        self.emit.printout(self.emit.emitIFFALSE(brk, o.frame))
        self.emit.printout(self.emit.emitGOTO(start, o.frame))
        self.emit.printout(self.emit.emitLABEL(brk, o.frame))
        o.frame.exitLoop()

    def visitBreakStmt(self, ast, o):
        label = o.frame.getBreakLabel()
        self.emit.printout(self.emit.emitGOTO(label, o.frame))

    def visitContinueStmt(self, ast, o):
        label = o.frame.getContinueLabel()
        self.emit.printout(self.emit.emitGOTO(label, o.frame))

    def visitReturnStmt(self, ast, o):
        if ast.expr is None:
            # self.emit.printout(self.emit.emitRETURN(VoidType(), o.frame))
            self.emit.printout(self.emit.emitGOTO(
                o.frame.getEndLabel(), o.frame))
        else:
            code, typ = self.visit(ast.expr, Access(o.frame, o.sym, False))
            self.emit.printout(code)
            *_, sym = filter(lambda x: o.frame.name == x.name, o.sym)
            if type(sym.mtype.rettype) is FloatType and type(typ) is IntegerType:
                self.emit.printout(self.emit.emitI2F(o.frame))
            # self.emit.printout(self.emit.emitRETURN(typ, o.frame))
            self.emit.printout(self.emit.emitGOTO(
                o.frame.getEndLabel(), o.frame))

    def visitCallStmt(self, ast, o):
        ctxt = o
        frame = ctxt.frame
        nenv = ctxt.sym
        *_, sym = filter(lambda x: ast.name == x.name, nenv)

        cname = sym.value.value
        ctype = sym.mtype
        partype = sym.mtype.partype
        in_ = ("", [])
        for x in range(len(ast.args)):
            str1, typ1 = self.visit(
                ast.args[x], Access(frame, nenv, False, True))
            if type(typ1) is IntegerType and type(partype[x]) is FloatType:
                typ1 = FloatType()
                str1 += self.emit.emitI2F(o.frame)
            in_ = (in_[0] + str1, in_[1] + [typ1])
        self.emit.printout(in_[0])
        if sym.isBuiltin:
            if 'print' in sym.name or 'write' in sym.name:
                if ast.name[5:] == 'Integer':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/string_of_int", MType([IntegerType()], StringType()), frame))
                elif ast.name[5:] == 'Float':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/string_of_float", MType([FloatType()], StringType()), frame))
                elif ast.name[5:] == 'Boolean':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/string_of_bool", MType([BooleanType()], StringType()), frame))
                self.emit.printout(self.emit.emitINVOKESTATIC(
                    cname + "/print", MType([StringType()], VoidType()), frame))
            else:
                self.emit.printout(self.emit.emitINVOKESTATIC(
                    cname + "/" + 'read', MType([], StringType()), frame))
                if ast.name[4:] == 'Integer':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/int_of_string", MType([StringType()], IntegerType()), frame))
                elif ast.name[4:] == 'Float':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/float_of_string", MType([StringType()], FloatType()), frame))
                elif ast.name[4:] == 'Boolean':
                    self.emit.printout(self.emit.emitINVOKESTATIC(
                        cname + "/bool_of_string", MType([StringType()], BooleanType()), frame))
        else:
            self.emit.printout(self.emit.emitINVOKESTATIC(
                cname + "/" + ast.name, ctype, frame))

    def visitBinExpr(self, ast, o):
        lcode, ltyp = self.visit(ast.left, o)
        rcode, rtyp = self.visit(ast.right, o)
        if ast.op in ['+', '-', '*', '/', '<', '>', '<=', '>='] and type(ltyp) != type(rtyp):
            if type(ltyp) is IntegerType:
                lcode = lcode + self.emit.emitI2F(o.frame)
                ltyp = FloatType()
            if type(rtyp) is IntegerType:
                rcode = rcode + self.emit.emitI2F(o.frame)
                rtyp = FloatType()
        if ast.op in ['+', '-']:
            return lcode + rcode + self.emit.emitADDOP(ast.op, ltyp, o.frame), ltyp
        elif ast.op in ['*', '/']:
            return lcode + rcode + self.emit.emitMULOP(ast.op, ltyp, o.frame), ltyp
        elif ast.op in ['%']:
            return lcode + rcode + self.emit.emitMOD(o.frame), IntegerType()
        elif ast.op in ['&&']:
            return lcode + rcode + self.emit.emitANDOP(o.frame), BooleanType()
        elif ast.op in ['||']:
            return lcode + rcode + self.emit.emitOROP(o.frame), BooleanType()
        elif ast.op in ['>', '<', '>=', '<=', '!=', '==']:
            return lcode + rcode + self.emit.emitREOP(ast.op, ltyp, o.frame), BooleanType()
        elif ast.op in ['::']:
            return lcode + rcode + self.emit.emitINVOKEVIRTUAL('java/lang/String/concat',
                                                               MType([StringType()], StringType()), o.frame), StringType()

    def visitUnExpr(self, ast, o):
        code, typ = self.visit(ast.val, o)
        if ast.op == '!':
            return code + self.emit.emitNOT(typ, o.frame), typ
        elif ast.op == '-':
            return code + self.emit.emitNEGOP(typ, o.frame), typ

    def visitId(self, ast, o):
        sym = None
        for i in o.sym:
            if i.name == ast.name:
                sym = i
                break
        if o.isLeft:
            if type(sym.value) is Index:
                code = self.emit.emitWRITEVAR(
                    sym.name, sym.mtype, sym.value.value, o.frame)
            else:
                code = self.emit.emitPUTSTATIC(
                    sym.value.value + '.' + sym.name, sym.mtype, o.frame)
        else:
            if type(sym.value) is Index:
                code = self.emit.emitREADVAR(
                    sym.name, sym.mtype, sym.value.value, o.frame)
            else:
                code = self.emit.emitGETSTATIC(
                    sym.value.value + '.' + sym.name, sym.mtype, o.frame)
        return code, sym.mtype

    def visitArrayCell(self, ast, o):
        res, typ = self.visit(Id(ast.name), Access(o.frame, o.sym, False))
        for i in range(len(ast.cell)-1):
            code, _ = self.visit(ast.cell[i], o)
            res += code
            res += self.emit.emitALOAD(typ, o.frame)
        code, _ = self.visit(ast.cell[-1], o)
        res += code
        # if o.isLeft:
        #     res += self.emit.emitASTORE(typ.typ, o.frame)
        # else:
        if not o.isLeft:
            if len(typ.dimensions) != len(ast.cell):
                res += self.emit.emitALOAD(
                    ArrayType(typ.dimensions[len(ast.cell):], typ.typ), o.frame)
                return res, ArrayType(typ.dimensions[len(ast.cell):], typ.typ)
            res += self.emit.emitALOAD(typ.typ, o.frame)
        return res, typ.typ

    def visitIntegerLit(self, ast, o):
        code = self.emit.emitPUSHICONST(ast.val, o.frame)
        return code, IntegerType()

    def visitFloatLit(self, ast, o):
        code = self.emit.emitPUSHFCONST(ast.val, o.frame)
        return code, FloatType()

    def visitStringLit(self, ast, o):
        code = self.emit.emitPUSHCONST(ast.val, StringType(), o.frame)
        return code, StringType()

    def visitBooleanLit(self, ast, o):
        code = self.emit.emitPUSHCONST(
            "true" if ast.val else "false", BooleanType(), o.frame)
        return code, BooleanType()

    def visitArrayLit(self, ast, o):
        typ = None
        tmp = self.emit.emitPUSHICONST(len(ast.explist), o.frame)
        res = ''
        for i in range(len(ast.explist)):
            res += self.emit.emitDUP(o.frame)
            res += self.emit.emitPUSHICONST(i, o.frame)
            code, typ = self.visit(ast.explist[i], o)
            res += code
            res += self.emit.emitASTORE(typ, o.frame)
        tmp += self.emit.emitNEWARRAY(typ)
        res = tmp + res
        if isinstance(typ, AtomicType):
            return res, ArrayType([len(code)], typ)
        else:
            return res, ArrayType([len(code)] + typ.dimensions, typ.typ)

    def visitFuncCall(self, ast, o):
        ctxt = o
        frame = ctxt.frame
        nenv = ctxt.sym
        *_, sym = filter(lambda x: ast.name == x.name, nenv)
        cname = sym.value.value
        ctype = sym.mtype
        partype = sym.mtype.partype
        in_ = ("", [])
        for x in range(len(ast.args)):
            str1, typ1 = self.visit(
                ast.args[x], Access(frame, nenv, False, True))
            if type(typ1) is IntegerType and type(partype[x]) is FloatType:
                typ1 = FloatType()
                str1 += self.emit.emitI2F(o.frame)
            in_ = (in_[0] + str1, in_[1] + [typ1])
        res = in_[0]
        if sym.isBuiltin:
            if 'print' in sym.name or 'write' in sym.name:
                if ast.name[5:] == 'Integer':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/string_of_int", MType([IntegerType()], StringType()), frame)
                elif ast.name[5:] == 'Float':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/string_of_float", MType([FloatType()], StringType()), frame)
                elif ast.name[5:] == 'Boolean':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/string_of_bool", MType([BooleanType()], StringType()), frame)
                res += self.emit.emitINVOKESTATIC(
                    cname + "/print", MType([StringType()], VoidType()), frame)
            else:
                res += self.emit.emitINVOKESTATIC(
                    cname + "/" + 'read', MType([], StringType()), frame)
                if ast.name[4:] == 'Integer':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/int_of_string", MType([StringType()], IntegerType()), frame)
                elif ast.name[4:] == 'Float':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/float_of_string", MType([StringType()], FloatType()), frame)
                elif ast.name[4:] == 'Boolean':
                    res += self.emit.emitINVOKESTATIC(
                        cname + "/bool_of_string", MType([StringType()], BooleanType()), frame)
        else:
            res += self.emit.emitINVOKESTATIC(
                cname + "/" + ast.name, ctype, frame)
        return res, ctype.rettype
