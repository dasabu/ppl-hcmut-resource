from MT22Visitor import MT22Visitor
from MT22Parser import MT22Parser
from AST import *

#2010236

class ASTGeneration(MT22Visitor):
    # Visit a parse tree produced by MT22Parser#program.
    def visitProgram(self, ctx:MT22Parser.ProgramContext):
        decls = self.visit((ctx.declare_list()))
        return Program(decls)

    # Visit a parse tree produced by MT22Parser#booleanlit.
    def visitBooleanlit(self, ctx:MT22Parser.BooleanlitContext):
        if ctx.TRUE():
            return BooleanLit(True)    # True
        else: 
            return BooleanLit(False)   # False


    # Visit a parse tree produced by MT22Parser#arraylit.
    def visitArraylit(self, ctx:MT22Parser.ArraylitContext):
        if ctx.getChildCount() == 2:
            return ArrayLit([])
        else:
            return ArrayLit(self.visit(ctx.expr_list())) #ArrayLit([])


    # Visit a parse tree produced by MT22Parser#atomic_type.
    def visitAtomic_type(self, ctx:MT22Parser.Atomic_typeContext):
        if ctx.INTEGER(): 
            return IntegerType()    # IntegerType()
        elif ctx.FLOAT(): 
            return FloatType()      # FloatType()
        elif ctx.BOOLEAN(): 
            return BooleanType()    # BooleanType()
        elif ctx.STRING(): 
            return StringType()     # StringType()


    # Visit a parse tree produced by MT22Parser#array_type.
    def visitArray_type(self, ctx:MT22Parser.Array_typeContext):
        dimen = self.visit(ctx.dimen_list())   # [1,2,3]
        type = self.visit(ctx.atomic_type())   # IntegerType()
        
        return ArrayType(dimen, type)


    # Visit a parse tree produced by MT22Parser#dimen_list.
    def visitDimen_list(self, ctx:MT22Parser.Dimen_listContext):
        if ctx.getChildCount() == 1: 
            return [int(ctx.INTLIT().getText())] 
        else : 
            return self.visit(ctx.dimen_list()) + [int(ctx.INTLIT().getText())]     #[1,2,3]


    # Visit a parse tree produced by MT22Parser#void_type.
    def visitVoid_type(self, ctx:MT22Parser.Void_typeContext):
        return VoidType()   # VoidType()


    # Visit a parse tree produced by MT22Parser#auto_type.
    def visitAuto_type(self, ctx:MT22Parser.Auto_typeContext):
        return AutoType()   # AutoType()


    # Visit a parse tree produced by MT22Parser#variable_type.
    def visitVariable_type(self, ctx:MT22Parser.Variable_typeContext):
        if ctx.atomic_type(): 
            return self.visit(ctx.atomic_type())
        elif ctx.array_type(): 
            return self.visit(ctx.array_type())
        else:
            return self.visit(ctx.auto_type())


    # Visit a parse tree produced by MT22Parser#varidecl.
    def visitVaridecl(self, ctx:MT22Parser.VarideclContext):
        if ctx.varidecl_short():
            return self.visit(ctx.varidecl_short()) #[]
        else:
            # full = self.visit(ctx.varidecl_full()) #[[][][]]
            # type = full[1]
            # return list(map(lambda i : VarDecl(full[0][i], type, full[2][i]), range(len(full[0]))))
            
            ####################################################
            full = self.visit(ctx.varidecl_full()) #[]
            lent = len(full)
            type = full[lent - 1][1]
            mid = lent//2
            
            for i in range(mid):
                tmp = full[i][2]
                full[i][2] = full[lent - i - 1][2]
                full[lent - i - 1][2] = tmp
            
            result = []
            for i in range(lent):
                result.append(VarDecl(full[i][0], type, full[i][2]))
            return result #[]
            

    # Visit a parse tree produced by MT22Parser#varidecl_short.
    def visitVaridecl_short(self, ctx:MT22Parser.Varidecl_shortContext):
        id_list = self.visit(ctx.identifier_list())              #  [a,b,c]
        type = self.visit(ctx.variable_type())                   #  type
        
        return list(map(lambda x: VarDecl(x, type), id_list))   # []


    # Visit a parse tree produced by M  T22Parser#varidecl_full.
    def visitVaridecl_full(self, ctx:MT22Parser.Varidecl_fullContext):
        if ctx.getChildCount() == 1:
            #return self.visit(ctx.varidecl_full1())
            return [self.visit(ctx.varidecl_full1())]
        else:
            # tmp = self.visit(ctx.varidecl_full()) #[[][][]]
            # tmp[0] = [id] + tmp[0]
            # tmp[2] += [expr]
            # return tmp
            # # #################################33
            id = ctx.IDENTIFIER().getText()
            expr = self.visit(ctx.expr())
            var = [id, None, expr]
            
            return [var] + self.visit(ctx.varidecl_full()) #[[][][]]

    # Visit a parse tree produced by MT22Parser#varidecl_full1.
    def visitVaridecl_full1(self, ctx:MT22Parser.Varidecl_full1Context):
        id = ctx.IDENTIFIER().getText()         # id
        type = self.visit(ctx.variable_type()) 
        expr = self.visit(ctx.expr())           # expr
        
        # tmp = [[],[],[]]
        # tmp[0] = [id] + tmp[0]
        # tmp[1] = type
        # tmp[2] += [expr]
        # return tmp #[[][][]]
        
        return [id, type, expr]


    # Visit a parse tree produced by MT22Parser#funcdecl.
    def visitFuncdecl(self, ctx:MT22Parser.FuncdeclContext):
        id = ctx.IDENTIFIER().getText()
        if ctx.variable_type() : 
            return_type = self.visit(ctx.variable_type())
        else:   
            return_type = self.visit(ctx.void_type())
        param = self.visit(ctx.parameter())
        
        if ctx.inherit_subpart():   inherit = self.visit(ctx.inherit_subpart())
        else: inherit = None  
        
        body = self.visit(ctx.func_body())
        
        fundecl = FuncDecl(id, return_type, param, inherit, body)
        
        return [fundecl]      # funcdecl


    # Visit a parse tree produced by MT22Parser#parameter.
    def visitParameter(self, ctx:MT22Parser.ParameterContext):
        if ctx.getChildCount() == 0:
            return []
        else:
            return self.visit(ctx.parameter_list())  # []


    # Visit a parse tree produced by MT22Parser#parameter_list.
    def visitParameter_list(self, ctx:MT22Parser.Parameter_listContext):
        if ctx.getChildCount() == 1:
            return [self.visit(ctx.parameterdecl())]
        else:
            return self.visit(ctx.parameter_list()) + [self.visit(ctx.parameterdecl())] #[]


    # Visit a parse tree produced by MT22Parser#parameterdecl.
    def visitParameterdecl(self, ctx:MT22Parser.ParameterdeclContext):
        id = ctx.IDENTIFIER().getText()
        type = self.visit(ctx.variable_type())
        if ctx.INHERIT() : inherit = True
        else:   inherit = False
        
        if ctx.OUT() : out = True
        else: out = False
        
        paramdecl = ParamDecl(id, type, out, inherit)
        
        return paramdecl


    # Visit a parse tree produced by MT22Parser#inherit_subpart.
    def visitInherit_subpart(self, ctx:MT22Parser.Inherit_subpartContext):
        return ctx.IDENTIFIER().getText()


    # Visit a parse tree produced by MT22Parser#func_body.
    def visitFunc_body(self, ctx:MT22Parser.Func_bodyContext):
        return  self.visit(ctx.block_stmt())


    # Visit a parse tree produced by MT22Parser#declare.
    def visitDeclare(self, ctx:MT22Parser.DeclareContext):
        if ctx.varidecl():
            return self.visit(ctx.varidecl()) #[]
        else:
            return self.visit(ctx.funcdecl())


    # Visit a parse tree produced by MT22Parser#expr_index.
    def visitExpr_index(self, ctx:MT22Parser.Expr_indexContext):
        name = ctx.IDENTIFIER().getText()
        cell = self.visit(ctx.expr_list())   # []
        array_cell = ArrayCell(name, cell)
        
        return array_cell

    def visitLiteral(self, ctx:MT22Parser.LiteralContext):
        if ctx.INTLIT(): 
            return IntegerLit(int(ctx.INTLIT().getText()))
        elif ctx.FLOATLIT():
            val = ctx.FLOATLIT().getText()
            if (val[0] == '.'):
                val = '0' + val
            return FloatLit(float(val))
        elif ctx.STRINGLIT():
            return StringLit(ctx.STRINGLIT().getText())
        elif ctx.booleanlit():
            return self.visit(ctx.booleanlit())
        else:
            return self.visit(ctx.arraylit())
            

    # Visit a parse tree produced by MT22Parser#expr.
    def visitExpr(self, ctx:MT22Parser.ExprContext):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr1()[0])
        else:
            op      = ctx.CONCAT().getText()           
            left    = self.visit(ctx.expr1()[0])
            right   = self.visit(ctx.expr1()[1])

            bin_expr = BinExpr(op, left, right)
            return bin_expr 

    # Visit a parse tree produced by MT22Parser#expr1.
    def visitExpr1(self, ctx:MT22Parser.Expr1Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr2()[0])
        else:
            if ctx.EQUAL():
                op = ctx.EQUAL().getText()
            elif ctx.NOTEQUAL():
                op = ctx.NOTEQUAL().getText()
            elif ctx.LESS():
                op = ctx.LESS().getText()
            elif ctx.GREATER():
                op = ctx.GREATER().getText()
            elif ctx.LESSE():
                op = ctx.LESSE().getText()
            else:
                op = ctx.GREATERE().getText()
            
            left    = self.visit(ctx.expr2()[0])
            right   = self.visit(ctx.expr2()[1])

            bin_expr = BinExpr(op, left, right)
            return bin_expr   


    # Visit a parse tree produced by MT22Parser#expr2.
    def visitExpr2(self, ctx:MT22Parser.Expr2Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr3())
        else:
            if ctx.CONJUNC():
                op = ctx.CONJUNC().getText()
            else:
                op = ctx.DISJUNC().getText()
            
            left    = self.visit(ctx.expr2())
            right   = self.visit(ctx.expr3())

            bin_expr = BinExpr(op, left, right)
            return bin_expr 


    # Visit a parse tree produced by MT22Parser#expr3.
    def visitExpr3(self, ctx:MT22Parser.Expr3Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr4())
        else:
            if ctx.ADD():
                op = ctx.ADD().getText()
            else:
                op = ctx.SUB().getText()
            
            left    = self.visit(ctx.expr3())
            right   = self.visit(ctx.expr4())

            bin_expr = BinExpr(op, left, right)
            return bin_expr 


    # Visit a parse tree produced by MT22Parser#expr4.
    def visitExpr4(self, ctx:MT22Parser.Expr4Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr5())
        else:
            if ctx.MULT():
                op = ctx.MULT().getText()
            elif ctx.REMAIN():
                op = ctx.REMAIN().getText()
            else:
                op = ctx.DIV().getText()
            
            left    = self.visit(ctx.expr4())
            right   = self.visit(ctx.expr5())

            bin_expr = BinExpr(op, left, right)
            return bin_expr    
            

    # Visit a parse tree produced by MT22Parser#expr5.
    def visitExpr5(self, ctx:MT22Parser.Expr5Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr6())
        else:
            op = ctx.NOT().getText()
            val = self.visit(ctx.expr5())
            
            un_expr = UnExpr(op, val)
            return un_expr


    # Visit a parse tree produced by MT22Parser#expr6.
    def visitExpr6(self, ctx:MT22Parser.Expr6Context):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.expr7())
        else:
            op = ctx.SUB().getText()
            val = self.visit(ctx.expr6())
            
            un_expr = UnExpr(op, val)
            return un_expr


    # Visit a parse tree produced by MT22Parser#expr7.
    def visitExpr7(self, ctx:MT22Parser.Expr7Context):
        if ctx.IDENTIFIER():
            return Id(ctx.IDENTIFIER().getText())
        elif ctx.literal():
            return self.visit(ctx.literal())
        elif ctx.funccall():
            return self.visit(ctx.funccall())
        elif ctx.expr_index():
            return self.visit(ctx.expr_index())
        else:
            return self.visit(ctx.expr())

    # Visit a parse tree produced by MT22Parser#funccall.
    def visitFunccall(self, ctx:MT22Parser.FunccallContext):
        name = ctx.IDENTIFIER().getText()
        args = self.visit(ctx.argument_list())

        funccall = FuncCall(name, args)
        return funccall

    # Visit a parse tree produced by MT22Parser#argument_list.
    def visitArgument_list(self, ctx:MT22Parser.Argument_listContext):
        if ctx.getChildCount() == 0:
            return []
        else:
            return self.visit(ctx.expr_list()) #[]


    # Visit a parse tree produced by MT22Parser#stmt.
    def visitStmt(self, ctx:MT22Parser.StmtContext):
        if ctx.assign_stmt():
            return self.visit(ctx.assign_stmt())
        elif ctx.if_stmt():
            return self.visit(ctx.if_stmt())
        elif ctx.for_stmt():
            return self.visit(ctx.for_stmt())
        elif ctx.while_stmt():
            return self.visit(ctx.while_stmt())
        elif ctx.dowhile_stmt():
            return self.visit(ctx.dowhile_stmt())
        elif ctx.break_stmt():
            return self.visit(ctx.break_stmt())
        elif ctx.continue_stmt():
            return self.visit(ctx.continue_stmt())
        elif ctx.return_stmt():
            return self.visit(ctx.return_stmt())
        elif ctx.call_stmt():
            return self.visit(ctx.call_stmt())
        else:
            return self.visit(ctx.block_stmt())

    # Visit a parse tree produced by MT22Parser#scalar_variable.
    def visitScalar_variable(self, ctx:MT22Parser.Scalar_variableContext):
        if ctx.IDENTIFIER():
            return Id(ctx.IDENTIFIER().getText())
        else:
            return self.visit(ctx.expr_index())
    

    # Visit a parse tree produced by MT22Parser#assign_stmt.
    def visitAssign_stmt(self, ctx:MT22Parser.Assign_stmtContext):
        scalar = self.visit(ctx.scalar_variable())
        expr =self.visit(ctx.expr())

        assign_stmt = AssignStmt(scalar, expr)
        return assign_stmt

    # Visit a parse tree produced by MT22Parser#if_stmt.
    def visitIf_stmt(self, ctx:MT22Parser.If_stmtContext):
        expr = self.visit(ctx.expr())
        fstmt = self.visit(ctx.stmt()[0])
        
        if ctx.getChildCount() == 7:
            sstmt = self.visit(ctx.stmt()[1])
        else:
            sstmt = None
        
        if_stmt = IfStmt(expr, fstmt, sstmt)
        return if_stmt


    # Visit a parse tree produced by MT22Parser#for_stmt.
    def visitFor_stmt(self, ctx:MT22Parser.For_stmtContext):
        scalar  = self.visit(ctx.scalar_variable())
        expr    = self.visit(ctx.expr()[0])

        init    = AssignStmt(scalar, expr)
        cond    = self.visit(ctx.expr()[1])
        upd     = self.visit(ctx.expr()[2])
        stmt    = self.visit(ctx.stmt())
        
        for_stmt = ForStmt(init, cond, upd, stmt)
        return for_stmt


    # Visit a parse tree produced by MT22Parser#while_stmt.
    def visitWhile_stmt(self, ctx:MT22Parser.While_stmtContext):
        cond    = self.visit(ctx.expr())
        stmt    = self.visit(ctx.stmt())
        
        while_stmt = WhileStmt(cond, stmt)
        return while_stmt


    # Visit a parse tree produced by MT22Parser#dowhile_stmt.
    def visitDowhile_stmt(self, ctx:MT22Parser.Dowhile_stmtContext):
        cond    = self.visit(ctx.expr())
        bstmt    = self.visit(ctx.block_stmt())
        
        dowhile_stmt = DoWhileStmt(cond, bstmt)
        return dowhile_stmt


    # Visit a parse tree produced by MT22Parser#break_stmt.
    def visitBreak_stmt(self, ctx:MT22Parser.Break_stmtContext):
        return BreakStmt()


    # Visit a parse tree produced by MT22Parser#continue_stmt.
    def visitContinue_stmt(self, ctx:MT22Parser.Continue_stmtContext):
        return ContinueStmt()


    # Visit a parse tree produced by MT22Parser#return_stmt.
    def visitReturn_stmt(self, ctx:MT22Parser.Return_stmtContext):
        if ctx.expr():
            expr = self.visit(ctx.expr())
        else:
            expr = None
        
        return_stmt = ReturnStmt(expr)
        return return_stmt


    # Visit a parse tree produced by MT22Parser#call_stmt.
    def visitCall_stmt(self, ctx:MT22Parser.Call_stmtContext):
        funccall = self.visit(ctx.funccall())
        name    =  funccall.name
        args    =  funccall.args
        
        call_stmt = CallStmt(name, args)
        return call_stmt


    # Visit a parse tree produced by MT22Parser#block_stmt.
    def visitBlock_stmt(self, ctx:MT22Parser.Block_stmtContext):
        return BlockStmt(self.visit(ctx.block_body()))


    # Visit a parse tree produced by MT22Parser#block_body.
    def visitBlock_body(self, ctx:MT22Parser.Block_bodyContext):
        if ctx.getChildCount() == 0:
            return []
        else:
            return self.visit(ctx.body_list())


    # Visit a parse tree produced by MT22Parser#body_list.
    def visitBody_list(self, ctx:MT22Parser.Body_listContext):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.body_prime())   #[]
        else:
            return self.visit(ctx.body_list()) + self.visit(ctx.body_prime()) #[]


    # Visit a parse tree produced by MT22Parser#body_prime.
    def visitBody_prime(self, ctx:MT22Parser.Body_primeContext):
        if ctx.stmt():
            return [self.visit(ctx.stmt())] #[]
        else:
            return self.visit(ctx.varidecl()) #[]


    # Visit a parse tree produced by MT22Parser#identifier_list.
    def visitIdentifier_list(self, ctx:MT22Parser.Identifier_listContext):
        if ctx.getChildCount() == 1: 
            return [ctx.IDENTIFIER().getText()]
        else:
            return self.visit(ctx.identifier_list()) + [ctx.IDENTIFIER().getText()]


    # Visit a parse tree produced by MT22Parser#declare_list.
    def visitDeclare_list(self, ctx:MT22Parser.Declare_listContext):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.declare())
        else:
            return self.visit(ctx.declare_list()) + self.visit(ctx.declare())


    # Visit a parse tree produced by MT22Parser#expr_list.
    def visitExpr_list(self, ctx:MT22Parser.Expr_listContext):
        if ctx.getChildCount() == 1:
            return [self.visit(ctx.expr())] #[]
        else:
            return self.visit(ctx.expr_list()) + [self.visit(ctx.expr())] #[]
