import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
    def test_501(self):
        input = """ a: integer = 23;
                    b: array [2,3] of integer = {{3,4,5},{6,7,8}}; 
                    main: function void () {
                        a: integer = 34;
                        printInteger(a);
                        printInteger(b[1,2]);
                    }"""
        expect = "348"
        self.assertTrue(TestCodeGen.test(input, expect, 501))

    def test_502(self):
        input = """ a: float = 1.0;
                    main: function void () {
                        {
                            a: float = 34.0;
                            writeFloat(a);
                        }
                        writeFloat(a);
                        writeFloat(12);
                    }"""
        expect = "34.01.012.0"
        self.assertTrue(TestCodeGen.test(input, expect, 502))

    def test_503(self):
        input = """ a: string = "Hello World";
                    main: function void () {
                        printString(a);
                        printString("\\nMT22");
                    }"""
        expect = "Hello World\nMT22"
        self.assertTrue(TestCodeGen.test(input, expect, 503))

    def test_504(self):
        input = """ a: boolean = true;
                    main: function void () {
                        printBoolean(a);
                        printBoolean(false);
                    }"""
        expect = "truefalse"
        self.assertTrue(TestCodeGen.test(input, expect, 504))

    def test_505(self):
        input = """ a: array [2] of string = {"Java", "Python"};
                    b: array [2,3] of float = {{2.3, 3.4, 534.666}, {5.67, 667.65, 6456.78}};
                    main: function void () {
                        c: array [1,3,2] of integer = {{{1,2},{3,4},{5,6}}};
                        printInteger(c[0,2,1]);
                        printString(" ");
                        writeFloat(b[1,1]);
                        printString(" ");
                        printString(a[1]);
                    }"""
        expect = "6 667.65 Python"
        self.assertTrue(TestCodeGen.test(input, expect, 505))

    def test_506(self):
        input = """ a: integer;
                    main: function void () {
                        b: float;
                        a = 120;
                        b = 1.2 + 2.3 * 2;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "120 5.8"
        self.assertTrue(TestCodeGen.test(input, expect, 506))

    def test_507(self):
        input = """ a: integer = 120 / 23 + 10;
                    main: function void () {
                        b: float;
                        b = 1.2 + 20 * 2;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "15 41.2"
        self.assertTrue(TestCodeGen.test(input, expect, 507))

    def test_508(self):
        input = """ a: integer = 120 / 23 + 10;
                    c: array [1,2] of integer = {{23, 34}};
                    main: function void () {
                        b: float;
                        a = a + c[0,1];
                        b = c[0,0] + 23;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "49 46.0"
        self.assertTrue(TestCodeGen.test(input, expect, 508))

    def test_509(self):
        input = """ a: integer = 120 / 23 + 10;
                    c: array [1,2] of integer = {{4, 34}};
                    main: function void () {
                        b: float = 78;
                        a = a % c[0,0];
                        b = b / c[0,1] + 23;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "3 25.294117"
        self.assertTrue(TestCodeGen.test(input, expect, 509))

    def test_510(self):
        input = """ a: boolean = true && false;
                    main: function void () {
                        b: boolean = true;
                        c: boolean = !a && b;
                        printBoolean(a);
                        printString(" ");
                        printBoolean(b);
                        printString(" ");
                        printBoolean(c);
                        printString(" ");
                        printBoolean(!(!c || !b) && b);
                    }"""
        expect = "false true true true"
        self.assertTrue(TestCodeGen.test(input, expect, 510))

    def test_511(self):
        input = """ a: string = "MT22";
                    main: function void () {
                        b: string = a :: "Class";
                        c: string;
                        c = b :: a;
                        printString(a :: "\\n");
                        printString(b :: "\\n");
                        printString(c);
                    }"""
        expect = "MT22\nMT22Class\nMT22ClassMT22"
        self.assertTrue(TestCodeGen.test(input, expect, 511))

    def test_512(self):
        input = """ a: integer = 23;
                    main: function void () {
                        b: float = 23.0;
                        printBoolean(a == 23);
                        printBoolean(false != true);
                        printBoolean(b > 10);
                        printBoolean(b < 10);
                        printBoolean(a >= 23.5);
                        printBoolean(b <= 23);
                    }"""
        expect = "truetruetruefalsefalsetrue"
        self.assertTrue(TestCodeGen.test(input, expect, 512))

    def test_513(self):
        input = """ foo: function integer (a: integer) {
                        return a * a;
                    }
                    main: function void () {
                        printInteger(foo(4));
                    }"""
        expect = "16"
        self.assertTrue(TestCodeGen.test(input, expect, 513))

    def test_514(self):
        input = """ 
                a: integer = foo(136);
                main: function void () {
                    printInteger(foo(a));
                }
                foo: function integer (a: integer) {
                    return a / 10;
                }
                """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 514))

    def test_515(self):
        input = """ 
                goo: function float (a: float) {
                    return a / 2;
                }
                main: function void () {
                    a: integer = 225;
                    b: float = goo(a) + foo(136);
                    writeFloat(b);
                }
                foo: function integer (a: integer) {
                    return a / 10;
                }
                """
        expect = "125.5"
        self.assertTrue(TestCodeGen.test(input, expect, 515))

    def test_516(self):
        input = """
                a: integer = 136;
                b: array [2,3,1] of integer = {{{1},{2},{3}},{{4},{5},{6}}}; 
                main: function void () {
                    t: integer = a;
                    m: array [3,1] of integer = b[1];
                    printInteger(m[0,0]);
                }
                """
        expect = "4"
        self.assertTrue(TestCodeGen.test(input, expect, 516))

    def test_517(self):
        input = """
            a: array [2,2] of string = {{"Java", "Python"},{"BKOOL", "MT22"}};
            main: function void() {
                a[1,1] = "C++";
                t: string = a[0,1];
                printString(a[1,1] :: t);
            }
            """
        expect = "C++Python"
        self.assertTrue(TestCodeGen.test(input, expect, 517))

    def test_518(self):
        input = """
            a: array [2,2] of string = {{"Java", "Python"},{"BKOOL", "MT22"}};
            foo: function void() {
                a[0,0] = (a[0,0] :: " ") :: a[0,1];
            }
            main: function void() {
                foo();
                foo();
                printString(a[0,0]);
            }
            """
        expect = "Java Python Python"
        self.assertTrue(TestCodeGen.test(input, expect, 518))

    def test_519(self):
        input = """
            a: array [2,2] of string;
            b: string;
            main: function void() {
                b = "Hello ";
                a[1,1] = "MT22";
                a[0,0] = "hihi";
                printString(b :: a[0,0]);
            }
            """
        expect = "Hello hihi"
        self.assertTrue(TestCodeGen.test(input, expect, 519))

    def test_520(self):
        input = """
            b: float;
            main: function void() {
                b = 12345;
                writeFloat(b);
            }
            """
        expect = "12345.0"
        self.assertTrue(TestCodeGen.test(input, expect, 520))

    def test_521(self):
        input = """
            main: function void() {
                a: integer = 23;
                if (a < 100) printString("True Statement");
                else {
                    printString("False Statement");
                }
            }
            """
        expect = "True Statement"
        self.assertTrue(TestCodeGen.test(input, expect, 521))

    def test_522(self):
        input = """
            main: function void() {
                a: integer = 136;
                if (a < 100) printString("True Statement");
                else {
                    printString("False Statement");
                }
            }
            """
        expect = "False Statement"
        self.assertTrue(TestCodeGen.test(input, expect, 522))

    def test_523(self):
        input = """
            foo: function boolean (a: integer, b: float) {
                if (a >= b) return true;
                else return false;
            }
            main: function void() {
                printBoolean(foo(23, 13.6));
            }
            """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input, expect, 523))

    def test_524(self):
        input = """
            foo: function boolean (a: integer, b: float) {
                if (a >= b) return true;
                else return false;
            }
            main: function void() {
                printBoolean(foo(12, 13.6));
            }
            """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input, expect, 524))

    def test_525(self):
        input = """
            main: function void() {
                a: integer = 45;
                if (a < 10) printString("a < 10");
                else if (a < 50) printString("10 <= a < 50");
                else printString("50 <= a");
            }
            """
        expect = "10 <= a < 50"
        self.assertTrue(TestCodeGen.test(input, expect, 525))

    def test_526(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i < 10, 1) {
                    printInteger(i);
                    printString(" ");
                }
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 526))

    def test_527(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i <= 10, 2) {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                }
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 527))

    def test_528(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i <= 10, 1) {
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                }
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 528))

    def test_529(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    for (j = 0, j < i, 1) {
                        if (j == 5) break;
                        printInteger(j+i);
                    }
                }
            }
            """
        expect = "123345456756789678910"
        self.assertTrue(TestCodeGen.test(input, expect, 529))

    def test_530(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                for (i = 0, i < 10, 1) res = res + i;
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 530))

    def test_531(self):
        input = """
            main: function void() {
                i: integer = 0;
                while (i < 10) {
                    printInteger(i);
                    printString(" ");
                    i = i + 1;
                }
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 531))

    def test_532(self):
        input = """
            main: function void() {
                i: integer = 0;
                while (i <= 10) {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                    i = i + 2;
                }
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 532))

    def test_533(self):
        input = """
            main: function void() {
                i: integer = -1;
                while (i <= 10) {
                    i = i + 1;
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                }
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 533))

    def test_534(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    while (j < i) {
                        if (j == 5) break;
                        printInteger(j+i);
                        j = j + 1;
                    }
                }
            }
            """
        expect = "13579"
        self.assertTrue(TestCodeGen.test(input, expect, 534))

    def test_535(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                while (i < 10)  {
                    res = res + i;
                    i = i + 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 535))

    def test_536(self):
        input = """
            main: function void() {
                i: integer = 0;
                do {
                    printInteger(i);
                    printString(" ");
                    i = i + 1;
                } while (i < 10);
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 536))

    def test_537(self):
        input = """
            main: function void() {
                i: integer = 0;
                do {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                    i = i + 2;
                } while (i <= 10);
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 537))

    def test_538(self):
        input = """
            main: function void() {
                i: integer = -1;
                do {
                    i = i + 1;
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                } while (i <= 10);
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 538))

    def test_539(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    do {
                        if (j == 5) break;
                        printInteger(j+i);
                        j = j + 1;
                    } while (j < i) ;
                }
            }
            """
        expect = "13579"
        self.assertTrue(TestCodeGen.test(input, expect, 539))

    def test_540(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                while (i < 10)  {
                    res = res + i;
                    i = i + 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 540))

    def test_541(self):
        input = """
            foo: function integer (i: integer) {
                return i * i;
            }
            main: function void() {
                printInteger(foo(10));
            }
            """
        expect = "100"
        self.assertTrue(TestCodeGen.test(input, expect, 541))

    def test_542(self):
        input = """
            foo: function integer (i: integer) {
                if (i == 0) {
                    i = i + 1;
                    return 1;
                }
                else {
                    return i * foo(i - 1);
                }
            }
            main: function void() {
                printInteger(foo(5));
            }
            """
        expect = "120"
        self.assertTrue(TestCodeGen.test(input, expect, 542))

    def test_543(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                for (res = 0, true, 0) {
                    if (i == 0) break;
                    res = res + i;
                    i = i - 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(5));
            }
            """
        expect = "15"
        self.assertTrue(TestCodeGen.test(input, expect, 543))

    def test_544(self):
        input = """
                fact: function integer (n: integer) {
                    if (n <= 1) return 1;
                    else return n * fact(n-1);
                }
                main: function void () {
                    x: integer = fact(8);
                    printInteger(x);
                }
            """
        expect = "40320"
        self.assertTrue(TestCodeGen.test(input, expect, 544))

    def test_545(self):
        input = """
                fact: function integer (n: integer) {
                    if (n <= 1) return 1;
                    i, res: integer = 0, 1;
                    for (i = 2, i <= n, 1) {
                        res = res * i;
                    }    
                    return res;
                }
                main: function void () {
                    printInteger(fact(2*3));
                }
            """
        expect = "720"
        self.assertTrue(TestCodeGen.test(input, expect, 545))

    def test_546(self):
        input = """
                arr: array[10] of float = {0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
                recSumArr: function float (arr: array [10] of float, idx: integer) {
                    if (idx == 9) return arr[9];
                    else return arr[idx] + recSumArr(arr, idx+1);
                }
                sumArr: function float (arr: array [10] of float) {
                    return recSumArr(arr, 0);
                }
                main: function void () {
                    writeFloat(sumArr(arr));
                }
            """
        expect = "45.0"
        self.assertTrue(TestCodeGen.test(input, expect, 546))

    def test_547(self):
        input = """
                arr: array[10] of float = {0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
                sumArr: function float (arr: array [10] of float) {
                    res: float = 0;
                    i: integer = 0;
                    while (i < 10) {
                        res = res + arr[i];
                        i = i + 1;
                    }
                    return res;
                }
                main: function void () {
                    writeFloat(sumArr(arr));
                }
            """
        expect = "45.0"
        self.assertTrue(TestCodeGen.test(input, expect, 547))

    def test_548(self):
        input = """
                gcdRec: function integer (n: integer, m: integer) {
                    if (m == 0) return n;
                    return gcdRec(m, n % m);
                }
                main: function void () {
                    printInteger(gcdRec(340, 23));
                }
            """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 548))

    def test_549(self):
        input = """
                gcd: function integer (n: integer, m: integer) {
                    while (m != 0) {
                        n = n % m;
                        tmp: integer = n;
                        n = m;
                        m = tmp;
                    }
                    return n;
                }
                main: function void () {
                    printInteger(gcd(340, 23));
                }
            """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 549))

    def test_550(self):
        input = """
            main: function void () {
                x : string = "qua";
                n : integer = 5;
                while (n != 0){
                    x: float = 10.2;
                    writeFloat(x);
                    n = n - 1;
                }
                printString(x);
            }
        """
        expect = """10.210.210.210.210.2qua"""
        self.assertTrue(TestCodeGen.test(input, expect, 550))

    def test_551(self):
        input = """ a: integer = 23;
                    b: array [2,3] of integer = {{3,4,5},{6,7,8}}; 
                    main: function void () {
                        a: integer = 34;
                        printInteger(a);
                        printInteger(b[1,2]);
                    }"""
        expect = "348"
        self.assertTrue(TestCodeGen.test(input, expect, 551))

    def test_552(self):
        input = """ a: float = 1.0;
                    main: function void () {
                        {
                            a: float = 34.0;
                            writeFloat(a);
                        }
                        writeFloat(a);
                        writeFloat(12);
                    }"""
        expect = "34.01.012.0"
        self.assertTrue(TestCodeGen.test(input, expect, 552))

    def test_553(self):
        input = """ a: string = "Hello World";
                    main: function void () {
                        printString(a);
                        printString("\\nMT22");
                    }"""
        expect = "Hello World\nMT22"
        self.assertTrue(TestCodeGen.test(input, expect, 553))

    def test_554(self):
        input = """ a: boolean = true;
                    main: function void () {
                        printBoolean(a);
                        printBoolean(false);
                    }"""
        expect = "truefalse"
        self.assertTrue(TestCodeGen.test(input, expect, 554))

    def test_555(self):
        input = """ a: array [2] of string = {"Java", "Python"};
                    b: array [2,3] of float = {{2.3, 3.4, 534.666}, {5.67, 667.65, 6456.78}};
                    main: function void () {
                        c: array [1,3,2] of integer = {{{1,2},{3,4},{5,6}}};
                        printInteger(c[0,2,1]);
                        printString(" ");
                        writeFloat(b[1,1]);
                        printString(" ");
                        printString(a[1]);
                    }"""
        expect = "6 667.65 Python"
        self.assertTrue(TestCodeGen.test(input, expect, 555))

    def test_556(self):
        input = """ a: integer;
                    main: function void () {
                        b: float;
                        a = 120;
                        b = 1.2 + 2.3 * 2;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "120 5.8"
        self.assertTrue(TestCodeGen.test(input, expect, 556))

    def test_557(self):
        input = """ a: integer = 120 / 23 + 10;
                    main: function void () {
                        b: float;
                        b = 1.2 + 20 * 2;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "15 41.2"
        self.assertTrue(TestCodeGen.test(input, expect, 557))

    def test_558(self):
        input = """ a: integer = 120 / 23 + 10;
                    c: array [1,2] of integer = {{23, 34}};
                    main: function void () {
                        b: float;
                        a = a + c[0,1];
                        b = c[0,0] + 23;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "49 46.0"
        self.assertTrue(TestCodeGen.test(input, expect, 558))

    def test_559(self):
        input = """ a: integer = 120 / 23 + 10;
                    c: array [1,2] of integer = {{4, 34}};
                    main: function void () {
                        b: float = 78;
                        a = a % c[0,0];
                        b = b / c[0,1] + 23;
                        printInteger(a);
                        printString(" ");
                        writeFloat(b);
                    }"""
        expect = "3 25.294117"
        self.assertTrue(TestCodeGen.test(input, expect, 559))

    def test_560(self):
        input = """ a: boolean = true && false;
                    main: function void () {
                        b: boolean = true;
                        c: boolean = !a && b;
                        printBoolean(a);
                        printString(" ");
                        printBoolean(b);
                        printString(" ");
                        printBoolean(c);
                        printString(" ");
                        printBoolean(!(!c || !b) && b);
                    }"""
        expect = "false true true true"
        self.assertTrue(TestCodeGen.test(input, expect, 560))

    def test_561(self):
        input = """ a: string = "MT22";
                    main: function void () {
                        b: string = a :: "Class";
                        c: string;
                        c = b :: a;
                        printString(a :: "\\n");
                        printString(b :: "\\n");
                        printString(c);
                    }"""
        expect = "MT22\nMT22Class\nMT22ClassMT22"
        self.assertTrue(TestCodeGen.test(input, expect, 561))

    def test_562(self):
        input = """ a: integer = 23;
                    main: function void () {
                        b: float = 23.0;
                        printBoolean(a == 23);
                        printBoolean(false != true);
                        printBoolean(b > 10);
                        printBoolean(b < 10);
                        printBoolean(a >= 23.5);
                        printBoolean(b <= 23);
                    }"""
        expect = "truetruetruefalsefalsetrue"
        self.assertTrue(TestCodeGen.test(input, expect, 562))

    def test_563(self):
        input = """ foo: function integer (a: integer) {
                        return a * a;
                    }
                    main: function void () {
                        printInteger(foo(4));
                    }"""
        expect = "16"
        self.assertTrue(TestCodeGen.test(input, expect, 563))

    def test_564(self):
        input = """ 
                a: integer = foo(136);
                main: function void () {
                    printInteger(foo(a));
                }
                foo: function integer (a: integer) {
                    return a / 10;
                }
                """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 564))

    def test_565(self):
        input = """ 
                goo: function float (a: float) {
                    return a / 2;
                }
                main: function void () {
                    a: integer = 225;
                    b: float = goo(a) + foo(136);
                    writeFloat(b);
                }
                foo: function integer (a: integer) {
                    return a / 10;
                }
                """
        expect = "125.5"
        self.assertTrue(TestCodeGen.test(input, expect, 565))

    def test_566(self):
        input = """
                a: integer = 136;
                b: array [2,3,1] of integer = {{{1},{2},{3}},{{4},{5},{6}}}; 
                main: function void () {
                    t: integer = a;
                    m: array [3,1] of integer = b[1];
                    printInteger(m[0,0]);
                }
                """
        expect = "4"
        self.assertTrue(TestCodeGen.test(input, expect, 566))

    def test_567(self):
        input = """
            a: array [2,2] of string = {{"Java", "Python"},{"BKOOL", "MT22"}};
            main: function void() {
                a[1,1] = "C++";
                t: string = a[0,1];
                printString(a[1,1] :: t);
            }
            """
        expect = "C++Python"
        self.assertTrue(TestCodeGen.test(input, expect, 567))

    def test_568(self):
        input = """
            a: array [2,2] of string = {{"Java", "Python"},{"BKOOL", "MT22"}};
            foo: function void() {
                a[0,0] = (a[0,0] :: " ") :: a[0,1];
            }
            main: function void() {
                foo();
                foo();
                printString(a[0,0]);
            }
            """
        expect = "Java Python Python"
        self.assertTrue(TestCodeGen.test(input, expect, 568))

    def test_569(self):
        input = """
            a: array [2,2] of string;
            b: string;
            main: function void() {
                b = "Hello ";
                a[1,1] = "MT22";
                a[0,0] = "hihi";
                printString(b :: a[0,0]);
            }
            """
        expect = "Hello hihi"
        self.assertTrue(TestCodeGen.test(input, expect, 569))

    def test_570(self):
        input = """
            b: float;
            main: function void() {
                b = 12345;
                writeFloat(b);
            }
            """
        expect = "12345.0"
        self.assertTrue(TestCodeGen.test(input, expect, 570))

    def test_571(self):
        input = """
            main: function void() {
                a: integer = 23;
                if (a < 100) printString("True Statement");
                else {
                    printString("False Statement");
                }
            }
            """
        expect = "True Statement"
        self.assertTrue(TestCodeGen.test(input, expect, 571))

    def test_572(self):
        input = """
            main: function void() {
                a: integer = 136;
                if (a < 100) printString("True Statement");
                else {
                    printString("False Statement");
                }
            }
            """
        expect = "False Statement"
        self.assertTrue(TestCodeGen.test(input, expect, 572))

    def test_573(self):
        input = """
            foo: function boolean (a: integer, b: float) {
                if (a >= b) return true;
                else return false;
            }
            main: function void() {
                printBoolean(foo(23, 13.6));
            }
            """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input, expect, 573))

    def test_574(self):
        input = """
            foo: function boolean (a: integer, b: float) {
                if (a >= b) return true;
                else return false;
            }
            main: function void() {
                printBoolean(foo(12, 13.6));
            }
            """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input, expect, 574))

    def test_575(self):
        input = """
            main: function void() {
                a: integer = 45;
                if (a < 10) printString("a < 10");
                else if (a < 50) printString("10 <= a < 50");
                else printString("50 <= a");
            }
            """
        expect = "10 <= a < 50"
        self.assertTrue(TestCodeGen.test(input, expect, 575))

    def test_576(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i < 10, 1) {
                    printInteger(i);
                    printString(" ");
                }
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 576))

    def test_577(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i <= 10, 2) {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                }
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 577))

    def test_578(self):
        input = """
            main: function void() {
                i: integer = 0;
                for (i = 0, i <= 10, 1) {
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                }
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 578))

    def test_579(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    for (j = 0, j < i, 1) {
                        if (j == 5) break;
                        printInteger(j+i);
                    }
                }
            }
            """
        expect = "123345456756789678910"
        self.assertTrue(TestCodeGen.test(input, expect, 579))

    def test_580(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                for (i = 0, i < 10, 1) res = res + i;
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 580))

    def test_581(self):
        input = """
            main: function void() {
                i: integer = 0;
                while (i < 10) {
                    printInteger(i);
                    printString(" ");
                    i = i + 1;
                }
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 581))

    def test_582(self):
        input = """
            main: function void() {
                i: integer = 0;
                while (i <= 10) {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                    i = i + 2;
                }
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 582))

    def test_583(self):
        input = """
            main: function void() {
                i: integer = -1;
                while (i <= 10) {
                    i = i + 1;
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                }
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 583))

    def test_584(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    while (j < i) {
                        if (j == 5) break;
                        printInteger(j+i);
                        j = j + 1;
                    }
                }
            }
            """
        expect = "13579"
        self.assertTrue(TestCodeGen.test(input, expect, 584))

    def test_585(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                while (i < 10)  {
                    res = res + i;
                    i = i + 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 585))

    def test_586(self):
        input = """
            main: function void() {
                i: integer = 0;
                do {
                    printInteger(i);
                    printString(" ");
                    i = i + 1;
                } while (i < 10);
                printInteger(i);
            }
            """
        expect = "0 1 2 3 4 5 6 7 8 9 10"
        self.assertTrue(TestCodeGen.test(input, expect, 586))

    def test_587(self):
        input = """
            main: function void() {
                i: integer = 0;
                do {
                    if (i > 5) {
                        printInteger(i);
                    }
                    else printInteger(i+10);
                    i = i + 2;
                } while (i <= 10);
            }
            """
        expect = "1012146810"
        self.assertTrue(TestCodeGen.test(input, expect, 587))

    def test_588(self):
        input = """
            main: function void() {
                i: integer = -1;
                do {
                    i = i + 1;
                    if (i == 3) continue;
                    else if (i > 5) break;
                    printInteger(i);
                } while (i <= 10);
            }
            """
        expect = "01245"
        self.assertTrue(TestCodeGen.test(input, expect, 588))

    def test_589(self):
        input = """
            main: function void() {
                i, j: integer = 0, 0;
                for (i = 0, i <= 6, 1) {
                    if (i == j) continue;
                    do {
                        if (j == 5) break;
                        printInteger(j+i);
                        j = j + 1;
                    } while (j < i) ;
                }
            }
            """
        expect = "13579"
        self.assertTrue(TestCodeGen.test(input, expect, 589))

    def test_590(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                while (i < 10)  {
                    res = res + i;
                    i = i + 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(1));
            }
            """
        expect = "45"
        self.assertTrue(TestCodeGen.test(input, expect, 590))

    def test_591(self):
        input = """
            foo: function integer (i: integer) {
                return i * i;
            }
            main: function void() {
                printInteger(foo(10));
            }
            """
        expect = "100"
        self.assertTrue(TestCodeGen.test(input, expect, 591))

    def test_592(self):
        input = """
            foo: function integer (i: integer) {
                if (i == 0) {
                    i = i + 1;
                    return 1;
                }
                else {
                    return i * foo(i - 1);
                }
            }
            main: function void() {
                printInteger(foo(5));
            }
            """
        expect = "120"
        self.assertTrue(TestCodeGen.test(input, expect, 592))

    def test_593(self):
        input = """
            foo: function integer (i: integer) {
                res: integer = 0;
                for (res = 0, true, 0) {
                    if (i == 0) break;
                    res = res + i;
                    i = i - 1;
                }
                return res;
            }
            main: function void() {
                printInteger(foo(5));
            }
            """
        expect = "15"
        self.assertTrue(TestCodeGen.test(input, expect, 593))

    def test_594(self):
        input = """
                fact: function integer (n: integer) {
                    if (n <= 1) return 1;
                    else return n * fact(n-1);
                }
                main: function void () {
                    x: integer = fact(8);
                    printInteger(x);
                }
            """
        expect = "40320"
        self.assertTrue(TestCodeGen.test(input, expect, 594))

    def test_595(self):
        input = """
                fact: function integer (n: integer) {
                    if (n <= 1) return 1;
                    i, res: integer = 0, 1;
                    for (i = 2, i <= n, 1) {
                        res = res * i;
                    }    
                    return res;
                }
                main: function void () {
                    printInteger(fact(2*3));
                }
            """
        expect = "720"
        self.assertTrue(TestCodeGen.test(input, expect, 595))

    def test_596(self):
        input = """
                arr: array[10] of float = {0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
                recSumArr: function float (arr: array [10] of float, idx: integer) {
                    if (idx == 9) return arr[9];
                    else return arr[idx] + recSumArr(arr, idx+1);
                }
                sumArr: function float (arr: array [10] of float) {
                    return recSumArr(arr, 0);
                }
                main: function void () {
                    writeFloat(sumArr(arr));
                }
            """
        expect = "45.0"
        self.assertTrue(TestCodeGen.test(input, expect, 596))

    def test_597(self):
        input = """
                arr: array[10] of float = {0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
                sumArr: function float (arr: array [10] of float) {
                    res: float = 0;
                    i: integer = 0;
                    while (i < 10) {
                        res = res + arr[i];
                        i = i + 1;
                    }
                    return res;
                }
                main: function void () {
                    writeFloat(sumArr(arr));
                }
            """
        expect = "45.0"
        self.assertTrue(TestCodeGen.test(input, expect, 597))

    def test_598(self):
        input = """
                gcdRec: function integer (n: integer, m: integer) {
                    if (m == 0) return n;
                    return gcdRec(m, n % m);
                }
                main: function void () {
                    printInteger(gcdRec(340, 23));
                }
            """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 598))

    def test_599(self):
        input = """
                gcd: function integer (n: integer, m: integer) {
                    while (m != 0) {
                        n = n % m;
                        tmp: integer = n;
                        n = m;
                        m = tmp;
                    }
                    return n;
                }
                main: function void () {
                    printInteger(gcd(340, 23));
                }
            """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input, expect, 599))

    def test_600_reversed_nested_funcdecl(self):
        input = """
        i: integer = 0;
        main:function void(){
            printInteger(double(inc(i)));
        }
        inc: function integer(i: integer){
            printInteger(i);
            return i+1;
        }
        double: function integer(i: integer){
            printInteger(i);
            return i*2;
        }
        """
        expect = "012"
        self.assertTrue(TestCodeGen.test(input, expect, 600))
